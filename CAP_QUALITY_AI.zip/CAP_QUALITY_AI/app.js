import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, StyleSheet } from 'react-native';
import Video from 'react-native-video';
import { Ionicons } from '@expo/vector-icons';

const App = () => {
  const [videoUri, setVideoUri] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState(null);

  const filters = ['Cinematic', 'Vintage', 'Vibrant'];

  const applyFilter = (filter) => {
    setSelectedFilter(filter);
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🎬 CAP QUALITY AI</Text>
      <TouchableOpacity style={styles.button} onPress={() => setVideoUri('path_to_video')}>
        <Ionicons name="videocam-outline" size={22} color="white" />
        <Text style={styles.buttonText}>إضافة فيديو</Text>
      </TouchableOpacity>

      {videoUri && (
        <Video
          source={{ uri: videoUri }}
          style={styles.video}
          resizeMode="contain"
          repeat
          filter={selectedFilter}
        />
      )}

      <TouchableOpacity style={styles.button} onPress={() => setModalVisible(true)}>
        <Ionicons name="color-palette-outline" size={22} color="white" />
        <Text style={styles.buttonText}>اختيار فلتر</Text>
      </TouchableOpacity>

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modal}>
          <Text style={styles.modalTitle}>اختر فلتر</Text>
          {filters.map((filter, index) => (
            <TouchableOpacity key={index} style={styles.modalButton} onPress={() => applyFilter(filter)}>
              <Text style={styles.modalButtonText}>{filter}</Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
            <Text style={styles.closeButtonText}>إغلاق</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f172a', alignItems: 'center', justifyContent: 'center', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#facc15', marginBottom: 20 },
  button: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#2563eb', padding: 12, borderRadius: 10, marginVertical: 6, width: 260, justifyContent: 'center' },
  buttonText: { color: 'white', fontSize: 16, fontWeight: '600' },
  video: { width: '100%', height: 180, backgroundColor: 'black', marginVertical: 20 },
  modal: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  modalTitle: { fontSize: 18, color: '#facc15', marginBottom: 10, fontWeight: 'bold' },
  modalButton: { backgroundColor: '#2563eb', padding: 10, borderRadius: 8, marginVertical: 5, width: 200, alignItems: 'center' },
  modalButtonText: { color: 'white', fontSize: 16, fontWeight: '600' },
  closeButton: { marginTop: 15, padding: 10, backgroundColor: '#ef4444', borderRadius: 8 },
  closeButtonText: { color: 'white', fontSize: 16 },
});

export default App;
